import "./topbar.scss"
import PersonIcon from '@material-ui/icons/Person';
import MailIcon from '@material-ui/icons/Mail';

export default function Topbar(props) {
    return (
        <div className={"topbar " + (props.menuOpen && "active") } >
            <div className="wrapper">
                <div className="left">
                    <a href="#intro" className="logo">TechTouhid</a>
                    <div className="itemContainer" >
                        <PersonIcon className="icon" />
                        <span>+8801748753174</span>
                    </div>
                    <div className="itemContainer" >
                        <MailIcon className="icon" />
                        <span>touhidurrahman1997@gmail.com</span>
                    </div>
                </div>

                <div className="right">
                    <div className="hamburger" onClick={()=> props.setMenuOpen(!props.menuOpen)}>
                        <span className="line1"></span>
                        <span className="line2"></span>
                        <span className="line3"></span>
                    </div>
                </div>
            </div>
        </div>
    )
}
